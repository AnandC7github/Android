package com.example.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText weight, height;
    TextView resulttext;
    String calculation, BMIresult;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        weight = findViewById(R.id.weight);
        height = findViewById(R.id.height);
        resulttext = findViewById(R.id.result);
    }

    public void calculateBMI(View view) {
        String S1 = weight.getText().toString();
        String S2 = height.getText().toString();

        float weightvalue = Float.parseFloat(S1);
        float heightvalue = Float.parseFloat(S2);

        float BMI = weightvalue / (heightvalue * heightvalue);

        if(BMI < 16){
            BMIresult = "Severly Underweight";
        }
        else if(BMI<18.5){
            BMIresult = "Underweight";
        }
        else if(BMI > 18.5 && BMI < 24.5){
            BMIresult = "Normal Weight";
        }
        else if(BMI > 24.5 && BMI < 29.5){
            BMIresult = "Overweight";
        }
        else{
            BMIresult = "Obese";
        }

        String Calculation = "Result:\n\n" + BMI + "\n" + BMIresult;
        resulttext.setText(Calculation);
    }
}